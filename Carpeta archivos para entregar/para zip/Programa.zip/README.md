# Practica


# Taquilla para parque de diversiones, descripción general

Se crea una aplicación para usar en un único computador ubicado en la taquilla del parque, en dicha aplicación se podrá gestionar reservas y entradas al parque, las cuales permiten crear una identificación del usuario (una tarjeta asociada a cada usuario) con la cual podrá acceder y obtener tiquetes para el uso de las instalaciones. El cliente podrá llamar a reservar su entrada, ya que el parque cuenta con un cupo diario limitado, esto se gestionará a través de un calendario, que permite llevar registro los ingresos y reservas para cada día. Las instalaciones se dividen en adultos e infantes, para lo cual, según la edad del cliente, podrá hacer uso de una u otra según su caso. 

Para el registro de los clientes, se podrá crear nuevos objetos asociados a cada uno, a los cuales se asociarán las reservas que solicite así como su tarjeta de usuario. 

También se llevará un registro de usos de las instalaciones, por si se requieren estadísticas de uso o saber cuándo se requiere realizar mantenimiento a una instalación. 

-----------------------------------------------------------
-----------------------------------------------------------
-----------------------------------------------------------


# Manual de Usuario:


Agregar una nueva instalacion:

Sobre las reservas:

Sobre los tiquetes:

Sobre la verificacion/creación de id de cliente:

Sobre la creación/verificación de tarjetas:

-----------------------------------------------------------
-----------------------------------------------------------
-----------------------------------------------------------




Descripción de la Implementación de características de programación orientada a objetos en el proyecto (indicando los
lugares y el modo en que se implementaron).


-----------------------------------------------------------
-----------------------------------------------------------
-----------------------------------------------------------

Funcionalidades


**////borrador

Borrador:
-Venta y descuento
-Reserva y sugerencia, y avisa de eventual descuento
-mantenimiento: Verifica numero de usos de instalacion y si toca mantenimiento, se aplica descuento
—funcionalidad con clase registro, para agregar registro de usos  de instalaciones, accesos al parque, tambien segun genero y edades. O en vez de clase registro, con los serializables ????
-falta una

///**
